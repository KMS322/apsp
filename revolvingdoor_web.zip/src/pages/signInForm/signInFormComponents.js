import SignInFormS1 from "./signInFormS1";
import SignInFormS2 from "./signInFormS2";
const SignInFormComponents = () => {
  return (
    <>
      <SignInFormS1 />
      <SignInFormS2 />
    </>
  );
};

export default SignInFormComponents;
