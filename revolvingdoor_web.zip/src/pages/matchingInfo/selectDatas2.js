export const dates = [{ value: "datesAll", label: "등록일 전체 ▼" }];

export const sortings = [
  { value: "sortingAll", label: "등록일 전체 ▼" },
  { value: "sorting1", label: "오름차순" },
  { value: "sorting2", label: "내림차순" },
];

export const condition_details = [
  { value: "conditionDetailAll", label: "상세조건 ▼" },
  { value: "condition_detail1", label: "상세조건1" },
  { value: "condition_detail2", label: "상세조건2" },
];
